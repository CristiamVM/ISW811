# Workshop 03

## Implementacion de proxy reverso

### Edicion del archivo << host >>
vamos a agregar los dominios que queremos crear en el archivo "host" de Windows(en mi caso), para acceder a este arhivo has que ir a "C:\Windows\System32\drivers\etc" y ejecutar este archivo como administrador para que nos deje guardar el archivo

![notepad]( ./Images/archivo%20host.PNG  "dominios agregados")


### Copiar los archivos de configuracion de VHOSTs
Ahora para los sitios nuevos que acabamos de crear vamos a crear el arhivo de configuracion del host virtual  esto se puede hacer desde la interfaz de usuario o si no desde terminal bash usando los comandos `code`, `touch`

```bash
  confs cp cristiam.isw811.xyz.conf lospatitos.com.conf
  confs cp cristiam.isw811.xyz.conf elblogcristiam.com.conf
  confs cp cristiam.isw811.xyz.conf lfts.isw811.xyz.conf
```

Luego reemplazamos las entradas correspondiente por el dominio que queremos remplazar

```bash
  sed -i -e 's/crist/.isw811\.xyz/lospatitos\.com/g' lospatitos.com.conf' lospatitos.com.conf
  sed -i -e 's/crist/lfts/g' lfts.isw811.xyz.conf
  sed -i -e 's/crist/elblogdemizaq\.com/g' elblogdemizaq.com.conf' elblogcristiam.com.conf
```

Para confirmar que los archivos se hayan modificado de manera correcta podemos usar el comando `cat`

```bash
  cat lospatitos.com.conf
  cat lfts.isw811.xyz.conf
  cat elblogcristiam.com.conf
```

Deberia quedar algo asi:

![explorador de arhivos]( ./Images/confs%20para%20los%20sitios%20nuevos.PNG "archivos conf creados")


### Crear los codigos para los dominios nuevos
Vamos a crear unos archivos dummys para los dominios que acabamos de crear, para que sea mas ordenado lo haremos en la misma carpeta que utilizamos la ultima vez

```bash
  mkdir lospatitos.com.conf
  mkdir lfts.isw811.xyz.conf
  mkdir elblogcristiam.com.conf
```
Una vez creadas las carpetas creamos el archivo HTML, en este caso creamos un archivo .html para cada carpeta que acabamos de crear y utilizamos visual studio code para modificar el archivo
  
```bash
  touch index.html
  code index.html
```

El archivo index.html deberia quedar similar al siguente

![Virtual Studio Code]( ./Images/indexdummy.PNG  "sitios default creados")

Deberia quedar algo asi en el explorador de archivos:

![explorador de arhivos]( ./Images/sitos%20de%20los%20dominios.PNG  "sitios default creados")


### Copiar los archivos .conf de los VHOSTS

 Utilizando la maquina virtual debemos copiar los archivos de configuracion de VHOSt a la ruta de los sitios disponibles de apache2

  Utilizando `*` podemos copiar todos los archivos `confs` al directorio de sitios disponibles
 ```bash
  cd /vagrant/confs
   sudo cp /vagrant/confs/* /etc/apache2/sites-available/
```

  Una vez hecho esto la carpeta de los sitios deberia quedar de la siguente manera

![terminal bash]( ./Images/agregamos%20los%20sitios%20a%20la%20carpeta%20sitios%20disponibles.PNG "sitios agregados a la carpeta de sitios disponibles")


### Habilitamos los sitios nuevos
Utilizamos el comando que se muestra abajo para habilitar los sitios que acabamos de crear y configurar

```bash
  sudo a2ensite lfts.isw811.xyz.conf
  sudo a2ensite elblogcristiam.com.conf
  sudo a2ensite lospatitos.com.conf
```
Ahora hay que recargar apache2 pero antes de esto vamos a comprobar que no alla error utlizamos el comando, si al ejecutar este muestra `Syntax OK` significa que todo esta bien y podemos reiniciar

```bash
 sudo apache2ctl -t
```
![terminal bash]( ./Images/syntax%20ok.PNG "los sitios se habilitaron correctamente")

Ahora podemos reiniciar, de la siguiente manera

```bash
 sudo systemctl reload apache2
```
y una vez reiniciado apache2 se deberia poder cargar las paginas que acabamos de crear

![Google Chrome]( ./Images/sitio%20elblog.PNG "los pagina cargada correctamente")

![Google Chrome]( ./Images/sitio%20lfts.PNG "los pagina cargada correctamente")

![Google Chrome]( ./Images/sitio%20lospatitos.PNG "los pagina cargada correctamente")

![Google Chrome]( ./Images/sitio%20cristiamisw811.PNG "los pagina cargada correctamente")


### Instalacion de composer
  descargamos e instalamos composer desde la maquina virtual, tambien vamos a habilitar el composer para poder utilizarlo desde cualquier parte y vamos a craftear un proyecto de laravel desde la maquina virtual

descargamos el composer y lo ejecutamos y por limpieza eliminamos el instalador 
```bash
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php
rm composer-setup.php
```

habilitamos el composer para que funcione desde cualquier parte
```bash
sudo mkdir -p /opt/composer/
sudo mv composer.phar /opt/composer/
sudo ln -s /opt/composer/composer.phar /usr/bin/composer
```

crafteamos el proyecto de laravel
```bash
cd /vagrant/sites
rm -r lfts.isw811.xyz
composer create-project laravel/laravel:8.6.12 lfts.isw811.xyz
```
![bash terminla]( ./Images/proyecto%20larabel.PNG "proyecto laravel creado")


Ahora tenemos que modificar el VHOST de lfts.isw811.xyz

![notepad]( ./Images/modificacion%20del%20conf%20de%20lfts.PNG "modificacion del archivo VHost")


Una vez modificado tenemos que volver a cambiar el archivo conf en la maquina virtual y reiniciamos apache2

```bash
 cp lfts.isw811.xyz.conf /etc/apache2/sites-available/
 sudo systemctl reload apache2
```

Y si hicimos todo bien, no deberiamos tener problemas para cargar la pagian por defecto de laravel

![Google Chrome]( ./Images/sitio%20laravel.PNG "pagina laravel funcionado")