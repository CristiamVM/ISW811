# Taller NMAP

## Introduccion

Algunas empresas no les da la importacia necesaria a los ciberatacantes, en el mundo a cada segundo se realizando constantemente muchos de ellos.

Pero esto no solo compete a las empresas, nos compete a nosotros como usuarios diarios de internet, ya sea con nuestros celulares, computadores o cualquier metodo que utilicemos para conectarnos a la red.

### La seguridad de la informacion se basa los siguientes pilares:

+ Confidencialidad
+ Integridad
+ Disponibilidad
+ Autenticacion
+ Validacion

Claramente detras de todo ataque hay una motivacion o meta, esta puede ser monetaria, de dañar reputacion, progagar informacion, robo de informacion, etc.

### Vectores de ataque

+ Virus y Worms
+ Botnet
+ Phishing
+ Web Application Threats
+ Inside attack
+ Ransomware
+ Could Computing Threats
+ Advance Persistent Threats
+ Mobile Threats
+ Internet of things Threads

### Tipos de atacantes

+ Organized Hacker
+ Script kiddies
+ Cyber Terrorists
+ Industrial Spies
+ Cyber Terrorists
+ Hacktivists
+ State-sponsed Attackers
+ Suicide Hackers
+ Recreational Hackers


### Ataque y Defensa

#### Red Team
Es el equipo encargado de las pruebas de seguridad.

#### Blue Team
Es la parte un poco mas administrativa de las repuestas.

#### Purple Team
Es el equipo que reune al ambos equipos.

## Fases de un ataque

### Footprinting
Es la parte de optencion de informacion y su principal objetivo es obtener informacion 
Mucha de esta informacion se optine en redes sociales, pero tambien se puede obtener de redes WIFI, y concientizacion de Usuarios.


### OSINT
 En esta parte ya tenemos la informacion, vamos a generar inteligencia, ya sea para utilizar ingenieria social, subplantacion de entidades, chantaje, etc.


## NMAP
 El pricipal funcion es escanear los puertos y asi vamos revisan que puertos estan abiertos, cuales estan cerrados y cuales esta filtrados(protegidos por firewall)

### Tipos de escaneo

+ Escaneo de conexion TCP (-sT)
+ Escaneo UDP (-sU)
+ Escaneo TCP FIN (-sF)
+ Escaneo de descubrimiento de host (-sN)
+ Opciones de sincronizacion (-T 0-5)


## Kali-linux
    Entramos en la maquina virtual e ingresamos en el root con el comando

    ´´´
        sudo -i
    ´´´

    Y despues para ver todos los comandos posibles utilizamos 

    ´´´
     man nmap
    ´´´

### Escaneo de descubrimiento de host
    En este caso tenemos el rango de ips de la 10.60.30.0/24

![Terminal Kali](./images/nmap%20test%20de%20host.png "Ver Los host disponibles")

### Testeamos un ataque al algunas Ip 

´´´
nmap "IP que queremos atacar con la mascara"
´´´

![Terminal Kali](./images/ataque%20a%20host.png "Ver Los host disponibles")

### Ver posibles vulnerabilidades
 ahora que usamos y tenemos la informacion del host podemos utilizar la siguiente pagina para comprobar vulnerabilidades

[Exploit database](https://www.exploit-db.com/)

### Metaexplot framework
 usamos el meta exploit para ver las vulnerabilidades

#### ver exploit

![Terminal Kali](./images/ataque%20a%20host.png "Ver Los host disponibles")

#### uso de exploit

![Terminal Kali](./images/usar%20exploit%20que%20encontramos.png "Usamos el exploit de VSFPF")

![Terminal Kali](./images/options%20del%20exploit.png "Usamos options para ver los posibilidades")

![Terminal Kali](./images/settear%20varible.png "setteamos la variable")

![Terminal Kali](./images/ver%20exploit.png "ejecutamos el exploit")


#### Para este ejemplo tenemos que asegurarnos que la ip de la maquina que queremos atacar esta en la mismo rango de IPs

![Terminal Kali](./images/host%20objetivo.png "ejecutamos el exploit")