# Workshop 05 - Bash Scripting

### Iniciamos la maquina Virutal de Database:

```bash
vagrant up
vagrant ssh 
```
### Creamos el archivo bash

``` bash
mkdir Scripts
touch hello.sh
code hello.sh
```
### Dentro del script hacemos una funcion de prueba

```bash
#!/bin/bash

echo "Hello World!"
```
### Para probar esto vamos a la maquina virutal, le damos permisos y ejecutamos el script

#### con "chmod le damos permisos de ejecucion"

![Terminal bash](Image/helloworld.PNG)

### Ahora queremos poder ejecutar el .sh desde cualquier parte

para esto ocupamos ejecutar la siguente linea de comando

```bash
export PATH=$PATH:/opt/scripts
```

#### "Solucion 1": el problema de esta es que la variable de entorno no se guarda cuando reiniciamos, para eso tenemos la seguda opcion

![Terminal bash](Image/solucion1.PNG)

#### Para resolver el problema de guardado podemos hacer lo siguente

```bash
nano .bashrc
```

![Terminal bash](Image/modificacion%20bash.PNG)

#### Solucion 2: Consite en hacer el binario sea accesible a travez de una de las rutas que ya forman parte de la varible de entorno PATH
 
![Terminal bash](Image/conexion%20simbolica.PNG)


### Creamos otro .sh al cual llamaremos helloworld

```bash
cd Scripts/
touch helloworld.sh
code helloworld.sh
```

![Terminal bash](Image/helloworld1.PNG)

#### Resultado del script helloworld

![Terminal bash](Image/helloworld1resultado.PNG)


### Ahora vamos a hacer un script que sea realmente util, para automatizar el backup de la base de datos northwind

![Terminal bash](Image/helloworld1resultado.PNG)


#### Resultado del script db-backup.sh

![Terminal bash](Image/helloworld1resultado.PNG)


### Cronjob
Identificamos el script que queremos correr y vamos al archivo que corre los cronjobs

```bash
crontab -e
```

![Terminal bash](Image/cronjobs.PNG)