# Workshop Northwind

## Norhtwind

### Copiamos los arvhivos de la base de datos a la carpeta de databases

![Terminal Bash](./images/tree%20northwind.PNG "Datos de northwind")

## MySQL

#### Vamos a la maquina virtual llamada database y utilizando mysql creamos un Usuario

![Terminal Bash](./images/creacion%20de%20la%20bb.PNG "Creacion de del usuario para la base de datos")


#### Creacion de la bd

![Terminal Bash](./images/creacion%20de%20la%20bb.PNG "Creacion de la base de datos")

#### Importar respaldo 

![Terminal Bash](./images/creacion%20de%20los%20datos%20de%20bd.PNG "Importamos los datos )

![Terminal Bash](./images/importar%20la%20base%20de%20datos.PNG "creamos las tablas y las columnas")


### Probamos que todo este correcto

![Terminal Bash](./images/importar%20la%20base%20de%20datos.PNG "Ver los datos creados")


## Challenge

### Challenge 1
Recupere el código (id) y la descripción (type_name) de los tipos de
movimiento de inventario (inventory_transaction_types).

![Workbench SQL](./images/challenge02.PNG "Challenge 1")


```sql
select id codigo, type_name descripcion from inventory_transaction_types;
```

### Challenge 2
Recupere la cantidad de ordenes (orders)
registradas por cada vendedor (employees)

![Workbench SQL](./images/challenge02.PNG "Challenge 2")

```sql
select concat(e.first_name, ' ', e.last_name) 'Vendedor', count(1) 'Cantidad' from orders o join employees e on e.id = o.employee_id group by e.id order by e.id;
```


### Challenge 3
Recupere la lista de los 10 productos más ordenados (order_details),
y la cantidad total de unidades ordenadas para cada uno de los
productos.
Deberá incluir como mínimo los campos de código (product_code),
nombre del producto (product_name) y la cantidad de unidades.

![Workbench SQL](./images/challenge03.PNG "Challenge 3")

```sql
select p.product_code, p.product_name, od.quantity from order_details od join products p on p.id = od.product_id;
```

### Challenge 4
Recupere el monto total (invoices, orders, order_details, products) y la
cantidad de facturas (invoices) por vendedor (employee). Debe
considerar solamente las ordenes con estado diferente de 0 y
solamente los detalles en estado 2 y 3, debe utilizar el precio
unitario de las lineas de detalle de orden, no considere el descuento,
no considere los impuestos, porque la comisión a los vendedores se
paga sobre el precio base.

![Workbench SQL](./images/challenge04.PNG "Challenge 4")

```sql
select count(1) 'Cantidad', concat(e.first_name, ' ', e.last_name) 'Vendedor',round(sum(od.quantity * od.unit_price), 2) 'Monto Facturado' from invoices i join orders o on o.id = i.order_id join order_details od on od.order_id = o.id join employees e	on e.id = o.employee_id where o.status_id <> 0 and od.status_id in (2, 3) group by e.id order by 'Cantidad' desc, 'Vendedor' asc;
```

### Challenge 5
Recupere los movimientos de inventario del tipo ingreso. Tomando
como base todos los movimientos de inventario
(inventory_transactions), considere unicamente el tipo de movimiento
1 (transaction_type) como ingreso.
Debe agrupar por producto (inventory_transactions.product_id) y
deberá incluir como mínimo los campos de código (product_code),
nombre del producto (product_name) y la cantidad de unidades
ingresadas.

![Workbench SQL](./images/challenge05.PNG "Challenge 5")

```sql
select p.product_code 'Código', p.product_name 'Producto', it.quantity 'Cantidad' from inventory_transactions it join products p on p.id = it.product_id where it.transaction_type = 1 group by p.id;
```

### Challenge 6
Recupere los movimientos de inventario del tipo salida. Tomando
como base todos los movimientos de inventario
(inventory_transactions), considere unicamente los tipos de
movimiento (transaction_type) 2, 3 y 4 como salidas.
Debe agrupar por producto (products) y deberá incluir como
mínimo los campos de código (product_code), nombre del producto
(product_name) y la cantidad de unidades que salieron.

![Workbench SQL](./images/challenge06.PNG "Challenge 6")

```sql
select p.product_code 'Código', p.product_name 'Producto', it.quantity 'Cantidad' from inventory_transactions it join products p on p.id = it.product_id where it.transaction_type = 2 or 3 or 4 group by p.id;
```

### Challenge 7
Genere un reporte de movimientos de inventario (inventory_transactions) por producto (products), tipo de transacción y
fecha, entre las fechas 22/03/2006 y 24/03/2006 (incluyendo ambas
fechas).
Debe incluir como mínimo el código (product_code), el nombre del
producto (product_name), la fecha truncada
(transaction_created_date), la descripción del tipo de movimiento
(type name) y la suma de cantidad (quantity)

![Workbench SQL](./images/challenge07.PNG "Challenge 7")

```sql
select p.product_code 'Código', p.product_name 'Producto', tt.type_name 'Tipo', DATE_FORMAT(it.transaction_created_date, "%d/%m/%Y") Fecha, sum(it.quantity) Cantidad from inventory_transactions it join products as p on p.id = it.product_id join inventory_transaction_types as tt on tt.id = it.transaction_type where it.transaction_created_date between '2006-03-22' and '2006-03-24'group by it.id asc order by p.product_name asc, Tipo desc;
```

### Challenge 8

![Workbench SQL](./images/challenge08.PNG "Challenge 8")
Genere la consulta SQL para un reporte de inventario, tomando como base todos los
movimientos de inventario (inventory_transactions), considere los tipos de movimiento
(transaction_type) 2, 3 y 4 como salidas y el tipo 1 como ingreso.
Este reporte debe estar agrupado por producto (products) y deberá incluir como
mínimo los campos de código (product_code), nombre del producto (product_name) y
la sumarización de ingresos, salidas y la cantidad disponible en inventario (diferencia
de ingresos - salidas)

```sql
SELECT p.product_code Código, p.product_name Producto, stats.Ingresos, stats.Salidas, stats.Ingresos - stats.Salidas AS Disponible FROM products as p INNER JOIN (SELECT it.product_id, sum(if(it.transaction_type = 1,quantity,0)) AS Ingresos, sum(if(it.transaction_type in (2,3,4),quantity,0)) AS Salidas FROM inventory_transactions it GROUP BY it.product_id) AS stats ON p.id = stats.product_id;
```