#WORKSHOP 01 - Vagrant

##Instalacion de VirtualBox
 VirtualBox es un hypervisor que vamos a 
 
 
 
 
 
 
 
 
 
 
p
 utilizar para hospedar una maquina virutal con Debian.

[VirtualBox]( https://www.virtualbox.org/wiki/Downloads "Descarga de VirtualBox")


##Instalacion de Vagrant
Vagrant es una herramienta open-source que junto a virtualBox permite un uso sensillo y rapido desde una terminal.

[Vagrant]( https://developer.hashicorp.com/vagrant/downloads "Descarga de Vagrant")

##Preparacion del vagrantfile
 luego ediamos el vagrantfile. par ahabilitar la red privada con la IP  192.168.146.10, vamso a editar y descomentar la linea 35, dejandola de la siguiente manera

 ![VisualStudioCode]( ./Images/vagrantfile.PNG "VagrantFile")

antes de lanzar el aprovisionamiento vamos a asegurarnos que la maquina virtual tenga la direccion de dominio de red privada que le vamos a asignar a nuestra maquina virtual

![VirtualBox](./Images/virtualbox.PNG "configuracion de host de red")

##Aprovechamiento de la maquina creada Bulleye
Creamos una maquina debia como demostracion y creamos unas carpetas dentro de maquina virtual desde la terminal de git.

![Bullseyes]( ./Images/bullseyes.jpg "Uso de markdown")


