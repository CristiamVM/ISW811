# Workshop 04- Creacion de la maquina virutal para la base de datos


### Asignamos Memoria RAM extra
Para evitar que nuestra maquina virtual este lenta a la hora de trabajar en ella le vamos a asignar RAM extra para evitar problemas, en mi caso le vamos a asignar 4gb de RAM

 ```
config.vm.provider "virtualbox" do |vb|
     vb.memory = "4048"
  end
 ```
 ### Creamos la maquina virutal

  le creamos asignamos una IP mas que la anterior, en este caso vamos a hacer configurar el VagrantFile, quedando de la siguiete manera

![Visual Studio Code]( ./Images/vagrantfile%20db.PNG "IP asignado a la maquina virtual")

####  Le cambiamos el nombre a la maquina

   Le cambiamos el hostname a la maquina virtual

```
  sudo hostnamectl set-hostname database  
```

Tambien le cambiamos para cambiar el nombre de maquina en el archivo host

```
  sudo nano /etc/hosts
``` 

## Actualizamos la maquina virutal
   actualizamos las librerias y demas archivos importante y despues instalamos el mysql-server y mysql-client
```maquina database
sudo apt-get update
sudo apt-get install mariadb-server mariadb-client  
```

 ****maquina webservice
    eliminamos el role de servidor a la maquina de webserver, esto para evitar confictos
```
sudo apt-get remove mariadb-server mariadb-client
```  

*** volvemos a la base de datos

```maquina database
sudo mysql
create user laravel identified by 'secret';
create datebase lfts;
grant all privileges on lfts;
flush privileges;
quit
```

ahora confirmamos la creacion de las tablas que acabamos de crear con los siguentes comandos:

```
mysql -u  laravel -p
show databases
```

Resultado:

![Terminal bash]( ./Images/confirmacion%20de%20creacion%20de%20tabla%20en%20base%20de%20datos.PNG "confirmacion de las tablas creadas")


## Habilitar acceso remoto
   Habilitamos el acceso remoto para tener acceso a la base de datos desde nuestra maquina anfitrion atravez de mysql workbench 

```
sudo nano /etc/mysql mariadb.conf.d/50/server.cnf
```
dentro de este archivo de configuracion buscamos "bind-address",  y le agregamos un "#" a esa linea y despues reiniciamos mysql

```
sudo systemctl restart mysql
```

Ahora para confirmar que se habilitara correctamente el acceso remoto desde la maquina webservice y con

```
   ping a 192.168.146.11
   mysql -u laravel -h "192.168.146.11" -p
```

![Terminal bash]( ./Images/ping%20de%20webserver%20a%20database.PNG "configuracion de la correcta implementacion del acceso remoto")

### instalamos NVM en la maquina webserver
   vamos a instalar el NVM en la maquina virtual utilizando

```
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
```

revisamos las versiones y en este caso vamos a utilizar la version "LTS Hydrogen"

```
nvm ls-remote
nvm install --lts=hydrogen
```

   Confirmamos la instalacion de las versiones correctas de las siguente manera

   ![Terminal bash]( ./Images/verificacion%20de%20versiones%20de%20node.PNG"confirmacion de instalacion de las versiones correctas")

### Instalamos laravel/UI
   Ahora vamos a instalar Laravel/UI, y para esto vamos a necesitar el Composer y el node.js, los cuales ya tenemos instalados por los pasos previos

```
cd /vagrant/sites/lfts.isw811.xyz
composer require laravel/ui:3.4.6
php artisan ui bootstrap
npm install && npm run dev
npm install && npm run dev
```

### craftear la vistas de autenticacion
   Construimos las vistas de autenticacion que da Laravel

```
php artisan ui bootstrap --auth
npm install && npm run dev
```

### Configuracion de los parametros de la base de datos
   Como si fuera un programa normal hay que establecer los paramentros de conexion a la base de datos, para esto vamos a el archivo de ambiente de laravel, en este caso ".env", y configuramos los datos de la base de datos para que quede de la siguiente manera

   ![Nano]( ./Images/configuracion%20de%20la%20conexion%20a%20la%20base%20de%20datos.PNG "Configuracion de paramentros para la conexion a la base de datos")


### Inicializacion de la base de datos
   Ahora estamos listos para inicializar la base de datos y para esto ejecutamos las migraciones del proyecto y artisan se encagara de crear las tablas, esto utilizando los paramentos de conexion previamente establecidos en el archivo de ambiente

```
cd /vagrant/sites/lfts.isw811.xyz
php artisan migrate
```

Confirmacion de la migracion:

   ![Terminal bash]( ./Images/confirmacion%20de%20la%20migracion%20db.PNG "correcta migracion de la base de datos")

### Apagar las maquinas virutales
   Ya tenemos todo correctamente configurado y listo ahora lo que queda es apagar las maquinas virtuales con el comando que ya conocemos, esto lo hacemos en ambas maquinas virtuales

   ```bash
      vagrant halt
   ```